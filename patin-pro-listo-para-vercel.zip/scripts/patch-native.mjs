// Ajustes nativos idempotentes tras `cap add android|ios`: orientación horizontal.
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
const am = 'android/app/src/main/AndroidManifest.xml';
if (existsSync(am)) {
  let x = readFileSync(am, 'utf8');
  if (!/android:screenOrientation=/.test(x)) { x = x.replace(/<activity\b/, '<activity\n            android:screenOrientation="sensorLandscape"'); writeFileSync(am, x); console.log('Android: orientación sensorLandscape aplicada'); }
}
const pl = 'ios/App/App/Info.plist';
if (existsSync(pl)) {
  let x = readFileSync(pl, 'utf8');
  const land = '<array>\n\t\t<string>UIInterfaceOrientationLandscapeLeft</string>\n\t\t<string>UIInterfaceOrientationLandscapeRight</string>\n\t</array>';
  x = x.replace(/(<key>UISupportedInterfaceOrientations(?:~ipad)?<\/key>\s*)<array>[\s\S]*?<\/array>/g, (m, k) => k + land);
  if (!/UIRequiresFullScreen/.test(x)) x = x.replace(/<\/dict>\s*<\/plist>/, '\t<key>UIRequiresFullScreen</key>\n\t<true/>\n</dict>\n</plist>');
  writeFileSync(pl, x); console.log('iOS: orientación horizontal aplicada');
}
