import asyncio,base64,sys
from playwright.async_api import async_playwright
W,H=int(sys.argv[1]),int(sys.argv[2]);tag=sys.argv[3]
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--use-gl=swiftshader','--enable-unsafe-swiftshader','--no-sandbox'])
        pg=await b.new_page(viewport={'width':W,'height':H});errs=[]
        pg.on('pageerror',lambda e:errs.append(str(e)[:160]))
        await pg.goto('http://localhost:8081/index.html');await pg.wait_for_timeout(3500)
        await pg.evaluate("adaptRes=function(){};PR=PRMAX;startGame();unlocked=29")
        out=f'/home/claude/proj/store/screenshots/{tag}'
        async def snap(n):await pg.screenshot(path=f'{out}-{n}.png')
        # 1 carrera
        await pg.evaluate("EV=EVENTS[1000];dreamM=-1;applyStage('robert');startRace()");await pg.wait_for_timeout(600)
        await pg.evaluate("introT=0");await pg.wait_for_timeout(400);await pg.evaluate("tcount=0");await pg.wait_for_timeout(500)
        await pg.evaluate("camW=0;window.__f=setInterval(()=>{if(state==='race'){sk[0].v=VMAX*.75;sk[0].fat=.3}},50)");await pg.wait_for_timeout(9000);await snap('race')
        # 2 inauguración (celebración)
        await pg.evaluate("clearInterval(window.__f);launchMission(3)");await pg.wait_for_timeout(500);await pg.evaluate("opS.t=7");await pg.wait_for_timeout(3000);await snap('opening')
        await pg.evaluate("opEnd()")
        # 3 podio
        await pg.evaluate("EV=EVENTS[500];dreamM=-1;applyStage('mundial');startRace()");await pg.wait_for_timeout(500)
        await pg.evaluate("sk.forEach((k,i)=>{k.place=i;k.fin=40+i});winner=sk[0];startPodium()");await pg.wait_for_timeout(32000);await snap('podium')
        # 4 crear patinador
        await pg.evaluate("buildMenu();state='create';drawCreate();crPrev()");await pg.wait_for_timeout(2000);await pg.evaluate("cuW=1;cuT.copy(sk[0].mesh.position)");await pg.wait_for_timeout(2500);await snap('create')
        # 5 selección
        await pg.evaluate("buildMenu();buildCards();selIdx=2;pickT=1;state='select';cuW=1");await pg.wait_for_timeout(2500);await snap('select')
        print(tag,errs);await b.close()
asyncio.run(main())
