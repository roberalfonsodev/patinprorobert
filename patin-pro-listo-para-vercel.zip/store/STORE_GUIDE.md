# Guía de publicación — Patin Pro

## Requisitos vigentes (verificados en octubre 2026)
| Tienda | Requisito |
|---|---|
| **Google Play** | Apps nuevas y actualizaciones deben apuntar a **Android 16 (API 36)** o superior (obligatorio desde el 31-ago-2026). Capacitor 8.x ya genera `targetSdk 36` y `minSdk 24` (corre en Android 7+, incluido Android 8). Sube un **AAB** firmado. |
| **App Store** | Desde el 28-abr-2026 toda subida debe compilarse con **Xcode 26+ / SDK iOS 26**. Requiere macOS, cuenta Apple Developer (99 USD/año) y registro en App Store Connect. El ícono de 1024×1024 va dentro del proyecto (Assets.xcassets), sin transparencia. |

> Estas reglas cambian cada año: confírmalas en developer.android.com/google/play/requirements/target-sdk y developer.apple.com/news/upcoming-requirements antes de publicar.

## A. Google Play
1. Crea la cuenta en Play Console y la app (nombre, idioma es-419, "Juego", gratis).
2. `npx cap add android` → `npm run assets` → `npm run cap:sync`.
3. En `android/app/build.gradle` confirma `versionCode` (entero que sube en cada publicación) y `versionName`. `applicationId` = `com.patinpro.game` (cámbialo antes de la primera subida si quieres otro: no se puede modificar después).
4. Android Studio → **Build > Generate Signed App Bundle** → crea tu *keystore* (**guárdalo y haz copia: sin él no podrás actualizar**) → `.aab`. Activa **Play App Signing**.
5. Ficha: usa `listing-es.md` / `listing-en.md`, ícono `icon-play-512.png`, gráfico `feature-graphic-1024x500.png`, capturas de `screenshots/play-*.png` (1920×1080; mínimo 2).
6. Política de privacidad: publica `www/privacy.html` en tu hosting y pega la URL (completa antes `[TU CORREO DE CONTACTO]`).
7. **Seguridad de los datos**: "No se recopilan ni comparten datos" (ver `data-safety.md`). Declara: sin anuncios, sin compras.
8. **Clasificación de contenido**: cuestionario IARC (deportes, sin violencia, sin chat, sin compras) → esperable "Para todos".
9. Público objetivo: si incluyes menores de 13 años, aplica la política de Familias; el juego no recopila datos.
10. Sube a **prueba interna/cerrada**, corrige y pasa a producción. (Las cuentas personales nuevas pueden requerir una prueba cerrada con testers antes de producción: revisa la regla vigente en Play Console.)

*Alternativa sin código nativo:* hospeda el PWA en HTTPS y empaquétalo como TWA con PWABuilder.com o Bubblewrap (también produce AAB). Necesitas publicar `/.well-known/assetlinks.json` con la huella SHA-256 de tu firma.

## B. App Store (iOS/iPadOS)
1. Cuenta Apple Developer; crea el *App ID* `com.patinpro.game` y el registro de la app en App Store Connect.
2. En macOS: `npx cap add ios` → `npm run assets` → `npm run cap:sync` → `npm run cap:ios`.
3. Xcode 26: elige tu *Team*, versión/build, **Signing & Capabilities** automático. Verifica orientación (solo horizontal) y que `PrivacyInfo.xcprivacy` esté presente (Capacitor lo incluye).
4. **Product > Archive > Distribute App > App Store Connect**. Prueba con **TestFlight**.
5. Ficha: textos de `listing-*.md`, palabras clave, URL de privacidad y de soporte. **Capturas obligatorias por tamaño de pantalla** (p. ej. iPhone 6.9″ 2868×1320 horizontal; iPad 13″ si la app es universal): genera las tuyas con `python3 make-screenshots.py <ancho> <alto> <etiqueta>` (con el juego servido en `localhost:8081`).
6. **Privacidad de la app**: "Datos no recopilados". **Clasificación por edad**: responde el cuestionario actualizado (resultado esperado 4+).
7. Guideline 4.2 (funcionalidad mínima): es un juego completo con 3D, audio y progreso; descríbelo así en las notas de revisión y no menciones "PWA/web".

## C. Checklist previo
- [ ] Correo de contacto y URL de política de privacidad publicados
- [ ] `applicationId` / Bundle ID definitivos
- [ ] Keystore guardado en 2 lugares
- [ ] Probado en un Android real de gama baja y en iPhone (sonido, rendimiento, orientación)
- [ ] Versiones de SDK vigentes (ver tabla)
- [ ] Capturas, ícono y gráfico cargados
- [ ] Nombres/marcas del juego (VESMAKO, CANARIOM, POWERSKATE, MTC, MATTERS) son ficticios: verifica que no coincidan con marcas registradas reales en los países donde publiques; igual con las banderas y nombres de países usados.
