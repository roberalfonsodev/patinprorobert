# Store listing — English

**Title (max 30):** Patin Pro: Speed Skating
**App Store subtitle (max 30):** Track, road & World Cup
**Short description (Play, max 80):** Race in speed skating: build your skater and reach the World Championships.

**Full description**
Lace up and become a champion! Patin Pro is a 3D speed-skating game where you race on track and road, create your own skater and progress from your club trials all the way to the Great World Skating Championship and the Marathon Championship.

• 30 missions across 5 phases: club trials, state qualifier, national qualifier, World Championship and Marathon.
• Real events: 200 m, 500 m, 1000 m, elimination, points, One Lap, 100 m lanes, 3200 m and Skill.
• Strategy: manage speed and fatigue, draft behind rivals and time your split.
• Simple controls: keyboard or on-screen buttons; the curve key sequence depends on turn direction (↑ ← or ↑ →).
• Skater creator: look, two-colour kit, club and country with live preview.
• Opening ceremonies, fireworks podium, cheering crowds and voice announcer.
• Unique venues: Seaside, Arena, RobertTrack, World Championship track and road, and the city.
• No ads, no purchases, no sign-up. Works offline.

**Keywords (max 100):** skating,inline,race,sports,speed,world cup,marathon,skates
**Category:** Games > Sports · **Rating:** Everyone / 4+
