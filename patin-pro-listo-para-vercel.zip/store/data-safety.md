# Formularios de privacidad / seguridad de datos

## Google Play — Seguridad de los datos
- ¿Recopila o comparte datos de usuario requeridos? **No**
- Recopilación de datos: ninguna (los datos del patinador se guardan solo en el dispositivo y no se transmiten)
- Cifrado en tránsito: no aplica (la app no envía datos)
- Eliminación de datos: no aplica (se borran al desinstalar)
- Anuncios: **No** · Compras dentro de la app: **No**
- Permisos Android: ninguno adicional (`INTERNET` lo añade Capacitor por defecto; puedes dejarlo)

## App Store — Privacidad de la app
- Tipos de datos recopilados: **Ninguno** ("Data Not Collected")
- Seguimiento (tracking): **No**
- APIs de "razón requerida": solo las del propio WebView/Capacitor (incluidas en su `PrivacyInfo.xcprivacy`)
