# Ficha de tienda — Español

**Título (máx. 30):** Patin Pro: Patinaje Veloz
**Subtítulo App Store (máx. 30):** Pista, ruta y Mundial
**Descripción corta Play (máx. 80):** Compite en patinaje de velocidad: crea tu patinador y llega al Mundial.

**Descripción completa**
¡Ponte los patines y conviértete en campeón! Patin Pro es un juego de patinaje de velocidad con gráficos 3D donde compites en pista y en ruta, creas tu propio patinador y recorres las fases desde el selectivo de tu club hasta el Gran Mundial de Patinaje y la Maratón Championship.

• 30 misiones en 5 fases: selectivo interno, válida departamental, válida nacional, Mundial y Maratón.
• Pruebas reales: 200 m, 500 m, 1000 m, eliminación, puntos, One Lap, 100 m carriles, 3200 m y Habilidad.
• Estrategia: administra tu velocidad y tu fatiga, aprovecha el rebufo y elige el momento del Spagatta.
• Controles simples: teclado o botones táctiles; en las curvas, la secuencia cambia según el sentido (↑ ← o ↑ →).
• Crea tu patinador: apariencia, uniforme de dos colores, club y país con vista previa en tiempo real.
• Ceremonias de inauguración, podio con fuegos artificiales, público animado y locución.
• Escenarios únicos: Malecón, Arena, RobertTrack, pista y ruta del Mundial y la ciudad.
• Sin anuncios, sin compras y sin registro. Funciona sin conexión.

**Palabras clave App Store (máx. 100):** patinaje,patines,carreras,deportes,velocidad,mundial,inline,speed skating,maratón
**Categoría:** Juegos > Deportes · **Clasificación:** Para todos / 4+
